// Obtém referência para o elemento de imagem
let imagemDestino = document.getElementById('imagemDestino');

// Obtém referências para os botões de informações específicos para cada destino
let botaoMaisInformacoes = document.getElementById('botaoMaisInformacoes');
let botaoMaisInformacoesTokyo = document.getElementById('botaoMaisInformacoesTokyo');
let botaoMaisInformacoesParis = document.getElementById('botaoMaisInformacoesParis');
let botaoMaisInformacoesNovaYork = document.getElementById('botaoMaisInformacoesNovaYork');

// Variável para controlar o intervalo do carrossel
let intervaloCarrossel;

// Função para criar o carrossel
function criarCarrossel(destino) {
    // Não é mais necessário criar vários elementos img, vamos usar um único elemento
    imagemDestino.src = `images/${destino}_1.jpg`; // Caminho ajustado
    imagemDestino.alt = `Imagem 1 de ${destino}`;
}

// Função para iniciar o carrossel
function iniciarCarrossel(destino) {
    let indiceAtual = 1; // Começamos com a segunda imagem (índice 1)
    const totalImagens = 2; // Total de imagens para o carrossel

    function mostrarProximaImagem() {
        imagemDestino.src = `images/${destino}_${indiceAtual}.jpg`; // Caminho ajustado
        imagemDestino.alt = `Imagem ${indiceAtual} de ${destino}`;
        indiceAtual = (indiceAtual % totalImagens) + 1;
    }

    // Mostra a primeira imagem
    mostrarProximaImagem();

    // Limpa o intervalo anterior antes de iniciar um novo
    clearInterval(intervaloCarrossel);

    // Inicia o intervalo para trocar de imagem a cada 7 segundos
    intervaloCarrossel = setInterval(mostrarProximaImagem, 7000);
}

// Função para mostrar a imagem e informações
function mostrarImagem(destino) {
    const detalhesTexto = document.getElementById('detalhesTexto');
    let info;

    // Define informações com base no destino
    switch (destino) {
        case 'paris':
            info = "Paris é conhecida como a Cidade Luz, famosa por sua arquitetura icônica, museus renomados e romantismo.";
            break;
        case 'nova-york':
            info = "Nova York, a cidade que nunca dorme, é um centro global de cultura, finanças e diversidade.";
            break;
        case 'toquio':
            info = "Tóquio é uma metrópole vibrante, misturando tradição e modernidade, com uma rica cena cultural e gastronômica.";
            break;
        default:
            info = "Informações gerais sobre o destino.";
            break;
    }

    detalhesTexto.textContent = `Imagem de ${destino}. ${info} Clique em "Mais Informações" para detalhes adicionais.`;

    // Adicionado chamada para iniciarCarrossel
    iniciarCarrossel(destino);

    imagemDestino.style.display = 'block';

    // Mostra o botão específico da região
    switch (destino) {
        case 'toquio':
            botaoMaisInformacoes.style.display = 'none';
            botaoMaisInformacoesTokyo.style.display = 'block';
            botaoMaisInformacoesParis.style.display = 'none';
            botaoMaisInformacoesNovaYork.style.display = 'none';
            break;
        case 'paris':
            botaoMaisInformacoes.style.display = 'none';
            botaoMaisInformacoesTokyo.style.display = 'none';
            botaoMaisInformacoesParis.style.display = 'block';
            botaoMaisInformacoesNovaYork.style.display = 'none';
            break;
        case 'nova-york':
            botaoMaisInformacoes.style.display = 'none';
            botaoMaisInformacoesTokyo.style.display = 'none';
            botaoMaisInformacoesParis.style.display = 'none';
            botaoMaisInformacoesNovaYork.style.display = 'block';
            break;
        default:
            // Para qualquer outro destino, mostra o botão geral
            botaoMaisInformacoes.style.display = 'block';
            botaoMaisInformacoesTokyo.style.display = 'none';
            botaoMaisInformacoesParis.style.display = 'none';
            botaoMaisInformacoesNovaYork.style.display = 'none';
            break;
    }
}

// Função para esconder a imagem e parar o carrossel
function esconderImagem() {
    const detalhesTexto = document.getElementById('detalhesTexto');
    detalhesTexto.textContent = 'Clique em um destino para ver a imagem. Clique em "Mais Informações" para ver detalhes adicionais.';

    imagemDestino.style.display = 'none';

    // Limpa o intervalo ao esconder a imagem
    clearInterval(intervaloCarrossel);
}

// Função para mostrar informações gerais
function maisInformacoes() {
    alert("Descubra um mundo de aventuras! Visite este destino para explorar paisagens deslumbrantes, mergulhar em culturas fascinantes e criar memórias inesquecíveis. Cada esquina reserva uma nova surpresa, aguardando para ser descoberta. Aproveite o melhor que este destino tem a oferecer e embarque em uma jornada emocionante!");
}

// Funções adicionais para mostrar informações específicas para cada destino
function maisInformacoesTokyo() {
    alert("Informações específicas sobre Tóquio. Adicione informações relevantes sobre Tóquio aqui.");
}

function maisInformacoesParis() {
    alert("Bem-vindo à Cidade Luz! Paris é conhecida por sua elegância, arte excepcional e romance que paira no ar. Descubra ícones como a Torre Eiffel, explore museus de renome mundial, delicie-se com a culinária requintada e desfrute de charmosos passeios pelas margens do rio Sena. Paris é mais do que uma cidade; é uma experiência inesquecível!");
}

function maisInformacoesNovaYork() {
    alert("Nova York, a cidade que nunca dorme, espera por você! Sinta a energia pulsante das luzes de Times Square, explore a Estátua da Liberdade, caminhe pelo Central Park e descubra os diversos bairros que fazem desta cidade um caldeirão cultural. Seja você amante da arte, da gastronomia ou da moda, Nova York tem algo para todos os gostos!");
}
