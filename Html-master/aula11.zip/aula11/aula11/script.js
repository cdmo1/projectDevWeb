// Declarando variáveis
var var1 = 10;
let let1 = 5;
const const1 = "15";

// Operação de adição e atualização da variável var1
var1 += let1;

// Atribuição de valor à div com id 'js'
document.getElementById('js').innerText ="Olá mundo \n";
document.getElementById('js').innerText += "Var = " + var1 + "let=" + let1 + "const =" + const1 +"\n";

// Mostrando tipos de variáveis
document.getElementById('js').innerText += "<hr> tipos Var = " + typeof(var1) + "tipo let=" + typeof(let1)  + "tipo const =" + typeof(const1)  +"\n";

// Adicionando uma linha horizontal à div
const js = document.getElementById('js');
js.innerHTML += "<hr>";

// Operadores Relacionais
js.innerHTML +="var1 com const1" +
"<br> var1 == const1 = " + (var1 == const1)+
"<br> var1 === const1 = " + (var1 === const1)+
"<br> var1 != const1 = " + (var1 != const1)+
"<br> var1 < const1 = " + (var1 < const1)+
"<br> var1 > const1 = " + (var1 > const1)+
"<br> var1 <= const1 = " + (var1 <= const1)+
"<br> var1 >= const1 = " + (var1 >= const1);

// Adicionando uma linha horizontal à div
js.innerHTML += "<hr>";

// Operadores Lógicos
js.innerHTML += 
"<br> var1 == const1 E var1 == let1 =" + (var1 == const1 && var1 == let1) +
"<br> var1 == const1 E var1 OU let1 =" + (var1 == const1 || var1 == let1) ;

// Estruturas de decisão

// Adicionando uma linha horizontal à div
js.innerHTML += "<hr>";

// Usando estrutura condicional "if"
if(var1++ == const1){
    js.innerHTML += "<h1> é igual </h1>";
} else {
    js.innerHTML += "<h1> <b> Nao </b> é igual </h1>";
}

// Usando operador ternário para uma decisão rápida
js.innerHTML += (var1 == const1)? "<h1> é igual </h1>": "<h1> <b> Nao </b> é igual </h1>";

// Usando estrutura de switch para verificar o dia da semana
const semana = ["segunda", "terça", "quarta","quinta","sexta"];
switch(semana[0]){
    case "segunda":
        js.innerHTML += "<h3>Segunda</h3>"
        break;
    case "terça":
        js.innerHTML += "<h3>terça</h3>"
        break;
    case "quarta":
        js.innerHTML += "<h3>quarta</h3>"
        break;
    case "quinta":
        js.innerHTML += "<h3>quinta</h3>"
        break;
    case "sexta":
        js.innerHTML += "<h3>sexta</h3>"
        break;
}
